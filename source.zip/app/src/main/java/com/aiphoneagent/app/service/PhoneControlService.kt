package com.aiphoneagent.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Accessibility Service - the "hands" of the AI Phone Agent.
 * Can read screen content and perform taps, scrolls, text input.
 */
class PhoneControlService : AccessibilityService() {

    companion object {
        var instance: PhoneControlService? = null
            private set

        private val _isEnabled = MutableStateFlow(false)
        val isEnabled: StateFlow<Boolean> = _isEnabled

        private val _lastScreenText = MutableStateFlow("")
        val lastScreenText: StateFlow<String> = _lastScreenText
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isEnabled.value = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        _isEnabled.value = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            rootInActiveWindow?.let { root ->
                _lastScreenText.value = extractText(root)
            }
        }
    }

    override fun onInterrupt() {}

    private fun extractText(node: AccessibilityNodeInfo, depth: Int = 0): String {
        if (depth > 20) return ""
        val sb = StringBuilder()
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()
        if (!text.isNullOrBlank()) sb.append(text).append("\n")
        if (!desc.isNullOrBlank() && desc != text) sb.append("[").append(desc).append("]\n")
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                sb.append(extractText(child, depth + 1))
                child.recycle()
            }
        }
        return sb.toString()
    }

    fun getScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val text = extractText(root)
        root.recycle()
        return text
    }

    fun tap(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    fun tapNode(node: AccessibilityNodeInfo): Boolean {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return if (rect.isEmpty) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            tap(rect.centerX().toFloat(), rect.centerY().toFloat())
            true
        }
    }

    fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val result = nodes.firstOrNull()
        nodes.forEach { if (it != result) it.recycle() }
        return result
    }

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return scrollNode(root)
    }

    private fun scrollNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isScrollable) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                if (scrollNode(child)) {
                    child.recycle()
                    return true
                }
                child.recycle()
            }
        }
        return false
    }

    fun inputText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun pressHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }
}
