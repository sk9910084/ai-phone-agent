package com.aiphoneagent.app.data.remote

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Manages REAL integrations via API keys and app detection.
 * Supports: YouTube (API key), Gmail (via app), WhatsApp (via app),
 * Telegram (Bot API), and generic webhook/API integrations.
 */
class IntegrationApiManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val prefs = context.getSharedPreferences("integrations", Context.MODE_PRIVATE)

    // YouTube Data API v3 - search videos
    suspend fun searchYouTube(apiKey: String, query: String): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Pehle YouTube API key dalein"))
        }
        try {
            val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=${java.net.URLEncoder.encode(query, "UTF-8")}&key=$apiKey&maxResults=5&type=video"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val err = try { JSONObject(body).getJSONObject("error").getString("message") } catch (e: Exception) { body.take(200) }
                return@withContext Result.failure(Exception("YouTube API Error: $err"))
            }
            val json = JSONObject(body)
            val items = json.getJSONArray("items")
            val sb = StringBuilder("YouTube results for '$query':\n\n")
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val snippet = item.getJSONObject("snippet")
                val videoId = item.getJSONObject("id").getString("videoId")
                sb.append("${i + 1}. ${snippet.getString("title")}\n")
                sb.append("   Channel: ${snippet.getString("channelTitle")}\n")
                sb.append("   https://youtube.com/watch?v=$videoId\n\n")
            }
            Result.success(sb.toString())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Telegram Bot API - send message
    suspend fun sendTelegramMessage(botToken: String, chatId: String, message: String): Result<String> = withContext(Dispatchers.IO) {
        if (botToken.isBlank() || chatId.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Pehle Telegram Bot Token aur Chat ID dalein"))
        }
        try {
            val url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=${java.net.URLEncoder.encode(message, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Telegram API Error: ${body.take(200)}"))
            }
            Result.success("Telegram message bhej diya!")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Check if app is installed (for WhatsApp, Gmail, etc.)
    fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    // API key storage
    fun saveApiKey(service: String, key: String) {
        prefs.edit().putString("api_key_$service", key).apply()
    }

    fun getApiKey(service: String): String {
        return prefs.getString("api_key_$service", "") ?: ""
    }

    // Verify YouTube API key is valid
    suspend fun verifyYouTubeKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=test&key=$apiKey&maxResults=1"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }
}
