package com.aiphoneagent.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiphoneagent.app.ui.theme.BackgroundDark
import com.aiphoneagent.app.ui.theme.CyanNeon
import com.aiphoneagent.app.ui.theme.SuccessGreen
import com.aiphoneagent.app.ui.theme.SurfaceCard
import com.aiphoneagent.app.ui.theme.SurfaceCardBorder
import com.aiphoneagent.app.ui.theme.TextPrimary
import com.aiphoneagent.app.ui.theme.TextSecondary
import com.aiphoneagent.app.ui.theme.VioletNeon

data class ToolItem(
    val name: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val color: Color,
    val samplePrompt: String
)

@Composable
fun ToolsHubScreen(
    onBack: () -> Unit,
    onToolSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Phone", "AI", "Productivity")

    val tools = listOf(
        ToolItem("Calls", "Call, Record, Transcribe", "Phone", Icons.Default.Call, SuccessGreen, "Important contact ko call lagao"),
        ToolItem("Messages", "Send, Read, Reply", "Phone", Icons.Default.Message, VioletNeon, "Unread SMS check karke summarize karo"),
        ToolItem("WhatsApp", "Chat, Media, Auto-reply", "Phone", Icons.Default.Send, SuccessGreen, "WhatsApp pe kal ki meeting ka update draft banao"),
        ToolItem("Email", "Send, Read, Organize", "Productivity", Icons.Default.Email, Color(0xFFEF5350), "Important work emails summarize karo"),
        ToolItem("Calendar", "Add, Manage, Remind", "Productivity", Icons.Default.CalendarMonth, Color(0xFFFF9800), "Kal ke saare events aur alarms set karo"),
        ToolItem("Files", "Read, Edit, Organize", "Productivity", Icons.Default.Folder, Color(0xFFFFB300), "Downloads folder me documents organize karo"),
        ToolItem("Camera", "Capture, Analyze", "Phone", Icons.Default.CameraAlt, CyanNeon, "Camera se bills aur receipts scan karo"),
        ToolItem("Gallery", "Search, Edit, Organize", "Phone", Icons.Default.PhotoLibrary, VioletNeon, "Gallery me duplicate screenshots dhundo"),
        ToolItem("Browser", "Web Search, Research", "AI", Icons.Default.Language, Color(0xFF42A5F5), "Offline AI agents architecture search karo"),
        ToolItem("Translator", "Multi-language", "AI", Icons.Default.Translate, Color(0xFF7E57C2), "English se Hindi me text convert karo"),
        ToolItem("Notes", "Create, Summarize", "Productivity", Icons.Default.Description, Color(0xFFFFCA28), "Project ideas ka naya quick note create karo"),
        ToolItem("Location", "Maps, Navigation", "Phone", Icons.Default.LocationOn, Color(0xFFE91E63), "Nearby safe parking spot navigate karo")
    )

    val filteredTools = if (selectedCategory == "All") tools else tools.filter { it.category == selectedCategory }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp)
            .testTag("tools_hub_screen"),
        contentPadding = PaddingValues(bottom = 80.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(2) }) {
            Column {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tools Hub",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Category Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanNeon.copy(alpha = 0.2f),
                                selectedLabelColor = CyanNeon,
                                containerColor = SurfaceCard,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedCategory == cat,
                                borderColor = SurfaceCardBorder,
                                selectedBorderColor = CyanNeon
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        items(filteredTools) { tool ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToolSelected(tool.samplePrompt) }
                    .testTag("tool_card_${tool.name}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(tool.color.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = tool.name,
                            tint = tool.color,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = tool.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = tool.subtitle,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}
