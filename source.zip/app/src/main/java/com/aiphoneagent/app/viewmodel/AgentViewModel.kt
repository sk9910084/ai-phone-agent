package com.aiphoneagent.app.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiphoneagent.app.data.local.AgentIntegration
import com.aiphoneagent.app.data.local.AgentLog
import com.aiphoneagent.app.data.local.AgentSkill
import com.aiphoneagent.app.data.local.AgentTask
import com.aiphoneagent.app.data.repository.AgentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Home : Screen("home")
    object TaskExecution : Screen("task_execution")
    object Result : Screen("result")
    object VoiceMode : Screen("voice_mode")
    object ToolsHub : Screen("tools_hub")
    object SelfLearning : Screen("self_learning")
    object Integrations : Screen("integrations")
    object Permissions : Screen("permissions")
    object Settings : Screen("settings")
    object Browser : Screen("browser")
}

data class QuickStats(
    val tasksCompleted: Int = 0,
    val skillsLearned: Int = 0,
    val uptime: String = "0m",
    val storageUsage: String = "12 KB"
)

class AgentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AgentRepository.getInstance(application)

    val allTasks: StateFlow<List<AgentTask>> = repository.getAllTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSkills: StateFlow<List<AgentSkill>> = repository.getAllSkills()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allIntegrations: StateFlow<List<AgentIntegration>> = repository.getAllIntegrations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<AgentLog>> = repository.getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeTaskId: StateFlow<Long?> = repository.activeTaskId

    private val _selectedTaskId = MutableStateFlow<Long?>(null)
    val selectedTaskId: StateFlow<Long?> = _selectedTaskId.asStateFlow()

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _activeTab = MutableStateFlow("home")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    val isPaused: StateFlow<Boolean> = repository.isExecutionPaused

    // FIX 2: Real QuickStats computed from Room DB, install time, and database file size
    val quickStats: StateFlow<QuickStats> = combine(
        repository.getCompletedTaskCount(),
        repository.getSkillCount()
    ) { completedCount, skillCount ->
        val uptimeStr = computeAppUptime(application)
        val storageStr = repository.getLocalDatabaseSize()
        QuickStats(
            tasksCompleted = completedCount,
            skillsLearned = skillCount,
            uptime = uptimeStr,
            storageUsage = storageStr
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        QuickStats(
            tasksCompleted = 0,
            skillsLearned = 0,
            uptime = computeAppUptime(application),
            storageUsage = repository.getLocalDatabaseSize()
        )
    )

    // FIX 3: API Key Management
    private val _geminiApiKey = MutableStateFlow(repository.apiKeyManager.getApiKey())
    val geminiApiKey: StateFlow<String> = _geminiApiKey.asStateFlow()

    fun updateGeminiApiKey(key: String) {
        repository.apiKeyManager.setApiKey(key)
        _geminiApiKey.value = repository.apiKeyManager.getApiKey()
        viewModelScope.launch {
            repository.refreshHonestIntegrations()
        }
        showToast("Gemini API Key save ho gayi hai.")
    }

    // FIX 1: Real Speech Recognizer & Voice States
    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private val _voiceRecognizedText = MutableStateFlow("")
    val voiceRecognizedText: StateFlow<String> = _voiceRecognizedText.asStateFlow()

    private val _voiceResponseText = MutableStateFlow("Sun raha hu... Aap boliye... Mai sun raha hu")
    val voiceResponseText: StateFlow<String> = _voiceResponseText.asStateFlow()

    private val _speechLanguage = MutableStateFlow("hi-IN")
    val speechLanguage: StateFlow<String> = _speechLanguage.asStateFlow()

    // Dialogs & Notifications
    private val _showApprovalDialog = MutableStateFlow<AgentTask?>(null)
    val showApprovalDialog: StateFlow<AgentTask?> = _showApprovalDialog.asStateFlow()

    private val _showUpdateDialog = MutableStateFlow(false)
    val showUpdateDialog: StateFlow<Boolean> = _showUpdateDialog.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    // Real Android SpeechRecognizer & TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    init {
        initTts(application)
        initSpeechRecognizer(application)

        // Observe active task status changes to show approval dialog or auto navigate to result
        viewModelScope.launch {
            allTasks.collect { tasks ->
                val active = tasks.firstOrNull { it.id == activeTaskId.value }
                if (active != null) {
                    if (active.status == "WAITING_FOR_APPROVAL") {
                        _showApprovalDialog.value = active
                    }
                    if (active.status == "COMPLETED" && _currentScreen.value == Screen.TaskExecution) {
                        _selectedTaskId.value = active.id
                        _currentScreen.value = Screen.Result
                    }
                }
            }
        }
    }

    private fun initTts(app: Application) {
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
            }
        }
    }

    private fun initSpeechRecognizer(app: Application) {
        if (SpeechRecognizer.isRecognitionAvailable(app)) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(app).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _voiceRecognizedText.value = ""
                            _voiceResponseText.value = "Sun raha hu... Aap boliye"
                        }

                        override fun onBeginningOfSpeech() {
                            _voiceResponseText.value = "Aawaz sun raha hu..."
                        }

                        override fun onRmsChanged(rmsdB: Float) {}

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _voiceResponseText.value = "Audio process kar raha hu..."
                        }

                        override fun onError(error: Int) {
                            _isVoiceListening.value = false
                            val msg = when (error) {
                                SpeechRecognizer.ERROR_AUDIO -> "Audio recording me samasya aayi"
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission grant karein"
                                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout ya speech service unavailable"
                                SpeechRecognizer.ERROR_NO_MATCH -> "Aawaz samajh nahi aayi, kripya dobara bolein ya type karein"
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi aawaz nahi suni gayi"
                                else -> "Speech recognition error ($error)"
                            }
                            _voiceResponseText.value = msg
                        }

                        override fun onResults(results: Bundle?) {
                            _isVoiceListening.value = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val recognized = matches?.firstOrNull() ?: ""
                            if (recognized.isNotBlank()) {
                                _voiceRecognizedText.value = recognized
                                _voiceResponseText.value = "Samajh gaya: \"$recognized\""
                                speak("Samajh gaya. Mai ispar kaam shuru kar raha hu.")
                            } else {
                                _voiceResponseText.value = "Kuch sunai nahi diya. Kripya dobara bolein."
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull()
                            if (!partial.isNullOrBlank()) {
                                _voiceRecognizedText.value = partial
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            } catch (e: Exception) {
                speechRecognizer = null
            }
        }
    }

    // FIX 1: Real Speech Recognizer toggle with permission verification
    fun toggleVoiceListening() {
        val app = getApplication<Application>()
        val hasPermission = ContextCompat.checkSelfPermission(
            app,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            _voiceResponseText.value = "Kripya Settings/Permissions me jakar Microphone permission allow karein."
            showToast("Microphone permission zaroori hai.")
            return
        }

        if (_isVoiceListening.value) {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {}
            _isVoiceListening.value = false
            return
        }

        if (speechRecognizer == null) {
            initSpeechRecognizer(app)
        }

        if (speechRecognizer == null) {
            _voiceResponseText.value = "Device par Speech recognition service uplabdh nahi hai. Kripya keyboard se type karein."
            showToast("Speech Recognizer not available on device")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            _voiceRecognizedText.value = ""
            _voiceResponseText.value = "Sun raha hu... Aap boliye"
            _isVoiceListening.value = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isVoiceListening.value = false
            _voiceResponseText.value = "Speech start error: ${e.localizedMessage}"
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AgentTTS")
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
        when (screen) {
            Screen.Home -> _activeTab.value = "home"
            Screen.TaskExecution, Screen.Result -> _activeTab.value = "tasks"
            Screen.VoiceMode -> _activeTab.value = "agent"
            Screen.ToolsHub -> _activeTab.value = "tools"
            Screen.Settings, Screen.SelfLearning, Screen.Integrations, Screen.Permissions -> _activeTab.value = "profile"
            else -> {}
        }
    }

    fun selectBottomTab(tab: String) {
        _activeTab.value = tab
        when (tab) {
            "home" -> _currentScreen.value = Screen.Home
            "tasks" -> {
                val currentRunning = allTasks.value.firstOrNull { it.status == "RUNNING" || it.status == "WAITING_FOR_APPROVAL" }
                val lastCompleted = allTasks.value.firstOrNull { it.status == "COMPLETED" }
                if (currentRunning != null) {
                    _currentScreen.value = Screen.TaskExecution
                } else if (lastCompleted != null) {
                    _selectedTaskId.value = lastCompleted.id
                    _currentScreen.value = Screen.Result
                } else {
                    _currentScreen.value = Screen.Home
                }
            }
            "agent" -> _currentScreen.value = Screen.VoiceMode
            "tools" -> _currentScreen.value = Screen.ToolsHub
            "profile" -> _currentScreen.value = Screen.Settings
        }
    }

    fun submitTask(instruction: String) {
        if (instruction.isBlank()) return

        // FIX 3: Prompt if API key is missing before executing
        if (!repository.apiKeyManager.hasValidApiKey()) {
            showToast("Pehle Settings me Gemini API key dalein")
            navigateTo(Screen.Settings)
            return
        }

        viewModelScope.launch {
            val taskId = repository.startNewTask(instruction)
            _selectedTaskId.value = taskId
            _currentScreen.value = Screen.TaskExecution
            speak("Samajh gaya. Mai aapke liye kaam shuru kar raha hu.")
        }
    }

    fun openTaskDetail(task: AgentTask) {
        _selectedTaskId.value = task.id
        if (task.status == "COMPLETED") {
            _currentScreen.value = Screen.Result
        } else {
            _currentScreen.value = Screen.TaskExecution
        }
    }

    fun pauseOrResumeTask() {
        repository.togglePauseTask()
    }

    fun cancelActiveTask() {
        val id = activeTaskId.value ?: selectedTaskId.value
        if (id != null) {
            viewModelScope.launch {
                repository.cancelTask(id)
                showToast("Task rok diya gaya hai.")
            }
        }
    }

    fun approveTask(task: AgentTask) {
        _showApprovalDialog.value = null
        viewModelScope.launch {
            repository.approveTask(task.id)
            showToast("Approval swikar kiya gaya. Kaam jari hai.")
        }
    }

    fun rejectTask(task: AgentTask) {
        _showApprovalDialog.value = null
        viewModelScope.launch {
            repository.rejectTask(task.id)
            showToast("Action ko mana kar diya gaya.")
        }
    }

    fun toggleIntegration(integration: AgentIntegration) {
        viewModelScope.launch {
            repository.toggleIntegration(integration)
        }
    }

    fun learnNewSkill(topic: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            repository.learnNewSkill(topic)
            showToast("Naya skill seekhna shuru kar diya: $topic")
        }
    }

    fun clearLocalStorage() {
        viewModelScope.launch {
            repository.clearAllLocalData()
            showToast("Phone ka local database clear kar diya gaya hai.")
        }
    }

    fun showToast(msg: String) {
        _notificationMessage.value = msg
        viewModelScope.launch {
            kotlinx.coroutines.delay(3000)
            if (_notificationMessage.value == msg) {
                _notificationMessage.value = null
            }
        }
    }

    fun setSpeechLanguage(lang: String) {
        _speechLanguage.value = lang
    }

    fun setUpdateDialog(show: Boolean) {
        _showUpdateDialog.value = show
    }

    fun getStorageUsage(): String {
        return repository.getLocalDatabaseSize()
    }

    private fun computeAppUptime(context: Context): String {
        return try {
            val packageInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
            val installTime = packageInfo.firstInstallTime
            val diffSec = ((System.currentTimeMillis() - installTime) / 1000).coerceAtLeast(1)
            val days = diffSec / (24 * 3600)
            val hours = (diffSec % (24 * 3600)) / 3600
            val minutes = (diffSec % 3600) / 60
            val seconds = diffSec % 60
            when {
                days > 0 -> "${days}d ${hours}h"
                hours > 0 -> "${hours}h ${minutes}m"
                minutes > 0 -> "${minutes}m ${seconds}s"
                else -> "${seconds}s"
            }
        } catch (e: Exception) {
            "0m"
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {}
        tts?.stop()
        tts?.shutdown()
    }
}
