package com.aiphoneagent.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiphoneagent.app.ui.components.FuturisticOrb
import com.aiphoneagent.app.ui.theme.BackgroundDark
import com.aiphoneagent.app.ui.theme.CyanNeon
import com.aiphoneagent.app.ui.theme.CyanNeonDim
import com.aiphoneagent.app.ui.theme.SuccessGreen
import com.aiphoneagent.app.ui.theme.SurfaceCard
import com.aiphoneagent.app.ui.theme.SurfaceCardBorder
import com.aiphoneagent.app.ui.theme.TextPrimary
import com.aiphoneagent.app.ui.theme.TextSecondary
import com.aiphoneagent.app.ui.theme.VioletNeon

@Composable
fun SplashScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(0.2f) }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, animationSpec = tween(2200))
        onFinished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .clickable { onFinished() }
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            FuturisticOrb(size = 180.dp)

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "AI Phone Agent",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Your Personal AI Assistant\nThat Can Do Everything",
                fontSize = 14.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(36.dp))

            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier
                    .width(180.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = CyanNeon,
                trackColor = SurfaceCardBorder
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Loading capabilities...",
                fontSize = 12.sp,
                color = CyanNeonDim
            )

            Spacer(modifier = Modifier.height(30.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(CyanNeon))
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(CyanNeon.copy(alpha = 0.5f)))
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(CyanNeon.copy(alpha = 0.2f)))
            }
        }
    }
}

@Composable
fun OnboardingScreen(
    onSetupDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(20.dp)
            .testTag("onboarding_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Welcome!",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Chaliye aapke AI Agent ko setup karte hain.",
                    fontSize = 15.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(28.dp))

                OnboardingFeatureCard(
                    icon = Icons.Default.PhoneAndroid,
                    iconColor = CyanNeon,
                    title = "Phone Control!",
                    subtitle = "Apps, Settings, Files sab control karein"
                )

                Spacer(modifier = Modifier.height(14.dp))

                OnboardingFeatureCard(
                    icon = Icons.Default.AutoAwesome,
                    iconColor = VioletNeon,
                    title = "AI se Har Tarah ke Tasks",
                    subtitle = "Work, Study, Personal automation"
                )

                Spacer(modifier = Modifier.height(14.dp))

                OnboardingFeatureCard(
                    icon = Icons.Default.Psychology,
                    iconColor = SuccessGreen,
                    title = "Self Learning",
                    subtitle = "Naye skills seekhna aur self-improve karna"
                )

                Spacer(modifier = Modifier.height(14.dp))

                OnboardingFeatureCard(
                    icon = Icons.Default.Security,
                    iconColor = CyanNeonDim,
                    title = "Privacy & Security",
                    subtitle = "Aapka data 100% aapke phone me local rahega"
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Button(
                    onClick = onSetupDone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("setup_start_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Setup Shuru Karein",
                            color = Color.Black,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Skip (Basic Mode)",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    modifier = Modifier
                        .clickable { onSetupDone() }
                        .padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun OnboardingFeatureCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(26.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }
    }
}
