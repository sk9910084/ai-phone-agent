package com.aiphoneagent.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aiphoneagent.app.ui.components.ApprovalDialog
import com.aiphoneagent.app.ui.components.BottomNavigationBar
import com.aiphoneagent.app.ui.components.UpdateProposalDialog
import com.aiphoneagent.app.ui.screens.HomeScreen
import com.aiphoneagent.app.ui.screens.IntegrationsScreen
import com.aiphoneagent.app.ui.screens.OnboardingScreen
import com.aiphoneagent.app.ui.screens.PermissionsScreen
import com.aiphoneagent.app.ui.screens.ResultScreen
import com.aiphoneagent.app.viewmodel.Screen
import com.aiphoneagent.app.ui.screens.SelfLearningScreen
import com.aiphoneagent.app.ui.screens.SettingsScreen
import com.aiphoneagent.app.ui.screens.SideDrawerContent
import com.aiphoneagent.app.ui.screens.SplashScreen
import com.aiphoneagent.app.ui.screens.TaskExecutionScreen
import com.aiphoneagent.app.ui.screens.ToolsHubScreen
import com.aiphoneagent.app.ui.screens.VoiceModeScreen
import com.aiphoneagent.app.ui.theme.BackgroundDark
import com.aiphoneagent.app.ui.theme.MyApplicationTheme
import com.aiphoneagent.app.viewmodel.AgentViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppRoot()
            }
        }
    }
}

@Composable
fun MainAppRoot(viewModel: AgentViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeTab by viewModel.activeTab.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val allSkills by viewModel.allSkills.collectAsState()
    val allIntegrations by viewModel.allIntegrations.collectAsState()
    val selectedTaskId by viewModel.selectedTaskId.collectAsState()
    val activeTaskId by viewModel.activeTaskId.collectAsState()
    val isPaused by viewModel.isPaused.collectAsState()

    val isVoiceListening by viewModel.isVoiceListening.collectAsState()
    val voiceRecognizedText by viewModel.voiceRecognizedText.collectAsState()
    val voiceResponseText by viewModel.voiceResponseText.collectAsState()

    val showApprovalDialog by viewModel.showApprovalDialog.collectAsState()
    val showUpdateDialog by viewModel.showUpdateDialog.collectAsState()
    val notificationMessage by viewModel.notificationMessage.collectAsState()
    val quickStats by viewModel.quickStats.collectAsState()
    val geminiApiKey by viewModel.geminiApiKey.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(notificationMessage) {
        notificationMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val selectedTask = allTasks.firstOrNull { it.id == (selectedTaskId ?: activeTaskId) }
        ?: allTasks.firstOrNull()

    // Back button handling
    BackHandler(enabled = currentScreen != Screen.Home) {
        when (currentScreen) {
            Screen.TaskExecution, Screen.Result, Screen.ToolsHub, Screen.Settings,
            Screen.SelfLearning, Screen.Integrations, Screen.Permissions, Screen.VoiceMode -> {
                viewModel.navigateTo(Screen.Home)
            }
            Screen.Onboarding -> viewModel.navigateTo(Screen.Home)
            else -> {}
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = BackgroundDark
            ) {
                SideDrawerContent(
                    tasksCount = quickStats.tasksCompleted,
                    skillsCount = quickStats.skillsLearned,
                    uptime = quickStats.uptime,
                    storageUsage = quickStats.storageUsage,
                    onNavigate = { screen ->
                        viewModel.navigateTo(screen)
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        val showBottomNav = currentScreen !in listOf(Screen.Splash, Screen.Onboarding, Screen.VoiceMode)

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = BackgroundDark,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomNav) {
                    BottomNavigationBar(
                        currentTab = activeTab,
                        onTabSelected = { tab ->
                            viewModel.selectBottomTab(tab)
                        }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BackgroundDark)
            ) {
                when (currentScreen) {
                    Screen.Splash -> {
                        SplashScreen(
                            onFinished = { viewModel.navigateTo(Screen.Home) }
                        )
                    }

                    Screen.Onboarding -> {
                        OnboardingScreen(
                            onSetupDone = { viewModel.navigateTo(Screen.Home) }
                        )
                    }

                    Screen.Home -> {
                        HomeScreen(
                            tasks = allTasks,
                            quickStats = quickStats,
                            onOpenDrawer = { scope.launch { drawerState.open() } },
                            onSubmitPrompt = { prompt -> viewModel.submitTask(prompt) },
                            onOpenTask = { task -> viewModel.openTaskDetail(task) },
                            onOpenVoiceMode = { viewModel.navigateTo(Screen.VoiceMode) }
                        )
                    }

                    Screen.TaskExecution -> {
                        TaskExecutionScreen(
                            task = selectedTask,
                            isPaused = isPaused,
                            onBack = { viewModel.navigateTo(Screen.Home) },
                            onPauseToggle = { viewModel.pauseOrResumeTask() },
                            onCancelTask = { viewModel.cancelActiveTask() },
                            onViewResult = { viewModel.navigateTo(Screen.Result) }
                        )
                    }

                    Screen.Result -> {
                        ResultScreen(
                            task = selectedTask,
                            onBack = { viewModel.navigateTo(Screen.Home) },
                            onNextAction = { action -> viewModel.submitTask(action) }
                        )
                    }

                    Screen.VoiceMode -> {
                        VoiceModeScreen(
                            isListening = isVoiceListening,
                            recognizedText = voiceRecognizedText,
                            responseText = voiceResponseText,
                            onToggleListening = { viewModel.toggleVoiceListening() },
                            onCloseVoiceMode = { viewModel.navigateTo(Screen.Home) },
                            onSubmitVoiceCommand = { cmd -> viewModel.submitTask(cmd) }
                        )
                    }

                    Screen.ToolsHub -> {
                        ToolsHubScreen(
                            onBack = { viewModel.navigateTo(Screen.Home) },
                            onToolSelected = { samplePrompt -> viewModel.submitTask(samplePrompt) }
                        )
                    }

                    Screen.SelfLearning -> {
                        SelfLearningScreen(
                            skills = allSkills,
                            onBack = { viewModel.navigateTo(Screen.Home) },
                            onStartLearningSkill = { skill -> viewModel.learnNewSkill(skill) }
                        )
                    }

                    Screen.Integrations -> {
                        IntegrationsScreen(
                            integrations = allIntegrations,
                            onToggle = { item -> viewModel.toggleIntegration(item) },
                            onBack = { viewModel.navigateTo(Screen.Home) }
                        )
                    }

                    Screen.Permissions -> {
                        PermissionsScreen(
                            onBack = { viewModel.navigateTo(Screen.Home) }
                        )
                    }

                    Screen.Settings -> {
                        SettingsScreen(
                            storageUsage = quickStats.storageUsage,
                            currentApiKey = geminiApiKey,
                            onSaveApiKey = { newKey -> viewModel.updateGeminiApiKey(newKey) },
                            onBack = { viewModel.navigateTo(Screen.Home) },
                            onOpenUpdates = { viewModel.setUpdateDialog(true) },
                            onClearLocalStorage = { viewModel.clearLocalStorage() },
                            onNavigateToIntegrations = { viewModel.navigateTo(Screen.Integrations) },
                            onNavigateToPermissions = { viewModel.navigateTo(Screen.Permissions) },
                            onNavigateToSelfLearning = { viewModel.navigateTo(Screen.SelfLearning) }
                        )
                    }
                }
            }
        }
    }

    // Modal Approval Dialog (Safety Engine)
    showApprovalDialog?.let { task ->
        ApprovalDialog(
            task = task,
            onApprove = { viewModel.approveTask(task) },
            onReject = { viewModel.rejectTask(task) }
        )
    }

    // Modal Update Proposal Dialog (Controlled Self-Update Engine)
    if (showUpdateDialog) {
        UpdateProposalDialog(
            onDismiss = { viewModel.setUpdateDialog(false) }
        )
    }
}
