package com.aiphoneagent.app.data.local

import android.content.Context
import android.content.SharedPreferences

class ApiKeyManager(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("agent_secure_prefs", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        // Priority 1: User explicitly entered in Settings screen
        val userKey = prefs.getString("gemini_api_key", "")?.trim() ?: ""
        if (userKey.isNotBlank()) return userKey

        // Priority 2: Injected via BuildConfig (Secrets panel / .env)
        return try {
            val buildConfigClass = Class.forName("com.aiphoneagent.app.BuildConfig")
            val field = buildConfigClass.getField("GEMINI_API_KEY")
            val configKey = (field.get(null) as? String)?.trim() ?: ""
            if (configKey.isNotBlank() &&
                !configKey.contains("MY_GEMINI_API_KEY") &&
                !configKey.contains("PLACEHOLDER")
            ) {
                configKey
            } else {
                ""
            }
        } catch (e: Throwable) {
            ""
        }
    }

    fun setApiKey(key: String) {
        prefs.edit().putString("gemini_api_key", key.trim()).apply()
    }

    fun hasValidApiKey(): Boolean {
        return getApiKey().isNotBlank()
    }
}
