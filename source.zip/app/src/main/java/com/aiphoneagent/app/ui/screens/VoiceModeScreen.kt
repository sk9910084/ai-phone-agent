package com.aiphoneagent.app.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiphoneagent.app.ui.theme.BackgroundDark
import com.aiphoneagent.app.ui.theme.CyanNeon
import com.aiphoneagent.app.ui.theme.CyanNeonDim
import com.aiphoneagent.app.ui.theme.DangerRed
import com.aiphoneagent.app.ui.theme.SurfaceCard
import com.aiphoneagent.app.ui.theme.SurfaceCardBorder
import com.aiphoneagent.app.ui.theme.SurfaceDark
import com.aiphoneagent.app.ui.theme.TextPrimary
import com.aiphoneagent.app.ui.theme.TextSecondary
import com.aiphoneagent.app.ui.theme.VioletNeon

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

@Composable
fun VoiceModeScreen(
    isListening: Boolean,
    recognizedText: String,
    responseText: String,
    onToggleListening: () -> Unit,
    onCloseVoiceMode: () -> Unit,
    onSubmitVoiceCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isSpeakerOn by remember { mutableStateOf(true) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onToggleListening()
        }
    }

    val requestVoiceStart = {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            onToggleListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "voiceWave")

    val wave1 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w1"
    )

    val wave2 by infiniteTransition.animateFloat(
        initialValue = 1.25f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(1900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w2"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(20.dp)
            .testTag("voice_mode_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isListening) "Sun raha hu..." else "Tap to Speak",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon
                )
                IconButton(onClick = onCloseVoiceMode) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
                }
            }

            // Center Pulsating Cyber Audio Visualizer
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .clickable { requestVoiceStart() },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(240.dp)) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = size.minDimension / 2.8f

                        // Outer glowing field
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(CyanNeon.copy(alpha = 0.35f), Color.Transparent),
                                center = center,
                                radius = radius * 1.5f * wave1
                            ),
                            radius = radius * 1.5f * wave1,
                            center = center
                        )

                        // Outer ring
                        drawCircle(
                            color = VioletNeon.copy(alpha = 0.6f),
                            radius = radius * 1.15f * wave2,
                            center = center,
                            style = Stroke(width = 3.dp.toPx())
                        )

                        // Inner audio ring
                        drawCircle(
                            color = CyanNeon,
                            radius = radius * wave1,
                            center = center,
                            style = Stroke(width = 2.5.dp.toPx())
                        )

                        // Center dark sphere
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF0F2038), Color(0xFF080C14)),
                                center = center,
                                radius = radius * 0.85f
                            ),
                            radius = radius * 0.85f,
                            center = center
                        )
                    }

                    // Sound Wave Bars in Center
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val barHeights = listOf(22.dp, 38.dp, 56.dp, 44.dp, 60.dp, 36.dp, 20.dp)
                        barHeights.forEachIndexed { idx, bh ->
                            val dynamicHeight = if (isListening) bh * if (idx % 2 == 0) wave1 else wave2 else 12.dp
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(dynamicHeight)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(CyanNeon)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Text(
                    text = if (isListening) "Sun raha hu..." else "Aap boliye...",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = responseText,
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )

                if (recognizedText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onSubmitVoiceCommand(recognizedText) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanNeon.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "\"$recognizedText\"",
                            fontSize = 13.sp,
                            color = CyanNeon,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        )
                    }
                }
            }

            // Bottom Buttons (Keyboard, Stop, Speaker)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 30.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Keyboard button
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, CircleShape)
                        .clickable { onCloseVoiceMode() }
                        .testTag("voice_keyboard_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = "Switch to Keyboard",
                        tint = TextPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Center Red Stop Button
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(DangerRed)
                        .clickable {
                            if (recognizedText.isNotBlank()) {
                                onSubmitVoiceCommand(recognizedText)
                            } else {
                                onCloseVoiceMode()
                            }
                        }
                        .testTag("voice_stop_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Stop",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }

                // Speaker button
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isSpeakerOn) CyanNeon.copy(alpha = 0.2f) else SurfaceCard)
                        .border(1.dp, if (isSpeakerOn) CyanNeon else SurfaceCardBorder, CircleShape)
                        .clickable { isSpeakerOn = !isSpeakerOn }
                        .testTag("voice_speaker_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Speaker Toggle",
                        tint = if (isSpeakerOn) CyanNeon else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
