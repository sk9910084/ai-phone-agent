package com.aiphoneagent.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Topic
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiphoneagent.app.data.local.AgentIntegration
import com.aiphoneagent.app.ui.theme.BackgroundDark
import com.aiphoneagent.app.ui.theme.CyanNeon
import com.aiphoneagent.app.ui.theme.SuccessGreen
import com.aiphoneagent.app.ui.theme.SurfaceCard
import com.aiphoneagent.app.ui.theme.SurfaceCardBorder
import com.aiphoneagent.app.ui.theme.TextPrimary
import com.aiphoneagent.app.ui.theme.TextSecondary
import com.aiphoneagent.app.ui.theme.VioletNeon
import com.aiphoneagent.app.ui.theme.WarningAmber

@Composable
fun IntegrationsScreen(
    integrations: List<AgentIntegration>,
    onToggle: (AgentIntegration) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabNames = listOf("Apps", "AI Models", "APIs")

    val filteredList = when (selectedTab) {
        0 -> integrations.filter { it.type == "APP" }
        1 -> integrations.filter { it.type == "AI_MODEL" }
        else -> integrations.filter { it.type == "API" || it.type == "APP" }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
            .testTag("integrations_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Integrations",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Honest status: Only verified services are marked Connected.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = SurfaceCard,
                contentColor = CyanNeon,
                indicator = {},
                divider = {},
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(12.dp))
            ) {
                tabNames.forEachIndexed { idx, name ->
                    val isSel = selectedTab == idx
                    Tab(
                        selected = isSel,
                        onClick = { selectedTab = idx },
                        modifier = Modifier
                            .background(if (isSel) CyanNeon.copy(alpha = 0.2f) else Color.Transparent)
                            .testTag("integration_tab_$name")
                    ) {
                        Text(
                            text = name,
                            color = if (isSel) CyanNeon else TextSecondary,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }

        items(filteredList) { item ->
            val iconVector = when (item.iconCategory) {
                "chat" -> Icons.Default.Send
                "email" -> Icons.Default.Email
                "folder" -> Icons.Default.Folder
                "video" -> Icons.Default.PlayCircle
                "notes" -> Icons.Default.Topic
                else -> Icons.Default.AutoAwesome
            }

            val iconColor = when (item.name) {
                "Local Phone Storage" -> SuccessGreen
                "WhatsApp" -> SuccessGreen
                "Gmail" -> Color(0xFFEF5350)
                "Google Drive" -> Color(0xFFFFB300)
                "YouTube" -> Color(0xFFE53935)
                "Notion" -> Color.White
                "Gemini AI Engine" -> CyanNeon
                "OpenAI" -> Color(0xFF00E676)
                "Claude" -> Color(0xFFFF7043)
                else -> VioletNeon
            }

            Card(
                modifier = Modifier.fillMaxWidth().testTag("integration_${item.name}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (item.isConnected) SuccessGreen.copy(alpha = 0.5f) else SurfaceCardBorder.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(iconColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(iconVector, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = item.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (item.isConnected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                            }
                        }
                        Text(
                            text = item.description,
                            fontSize = 11.sp,
                            color = if (item.isConnected) SuccessGreen else TextSecondary,
                            lineHeight = 15.sp
                        )
                    }

                    Switch(
                        checked = item.isConnected,
                        onCheckedChange = { onToggle(item) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = CyanNeon,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = SurfaceCardBorder
                        ),
                        modifier = Modifier.testTag("switch_${item.name}")
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
