package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00363D),
    onPrimaryContainer = Color(0xFF80F4FF),
    secondary = VioletNeon,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2C136A),
    onSecondaryContainer = Color(0xFFD6C7FF),
    tertiary = SuccessGreen,
    onTertiary = Color.Black,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceCardBorder,
    error = DangerRed,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme( // Keep futuristic contrast
    primary = CyanNeon,
    onPrimary = Color.Black,
    secondary = VioletNeon,
    onSecondary = Color.White,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Futuristic cyber theme is dark-first
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
