package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StatusPill
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PermissionsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val grantedMap = remember {
        mutableStateMapOf(
            "Accessibility" to true,
            "Notifications" to true,
            "Files & Media" to true,
            "Camera" to false,
            "Location" to false,
            "Call Log" to false
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
            .testTag("permissions_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Permissions",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Agent ko kaam karne ke liye kuch permissions chahiye.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            Text(
                text = "Essential",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = CyanNeon
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.AccessibilityNew,
                title = "Accessibility",
                subtitle = "Phone control ke liye",
                isGranted = grantedMap["Accessibility"] == true,
                onToggle = { grantedMap["Accessibility"] = !(grantedMap["Accessibility"] ?: false) }
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.Notifications,
                title = "Notifications",
                subtitle = "Messages & Alerts",
                isGranted = grantedMap["Notifications"] == true,
                onToggle = { grantedMap["Notifications"] = !(grantedMap["Notifications"] ?: false) }
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.Folder,
                title = "Files & Media",
                subtitle = "Read / Write local files",
                isGranted = grantedMap["Files & Media"] == true,
                onToggle = { grantedMap["Files & Media"] = !(grantedMap["Files & Media"] ?: false) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Optional",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.CameraAlt,
                title = "Camera",
                subtitle = "Capture & Analyze documents",
                isGranted = grantedMap["Camera"] == true,
                onToggle = { grantedMap["Camera"] = !(grantedMap["Camera"] ?: false) }
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.LocationOn,
                title = "Location",
                subtitle = "Maps & Navigation",
                isGranted = grantedMap["Location"] == true,
                onToggle = { grantedMap["Location"] = !(grantedMap["Location"] ?: false) }
            )
        }

        item {
            PermissionCard(
                icon = Icons.Default.Call,
                title = "Call Log",
                subtitle = "Call management",
                isGranted = grantedMap["Call Log"] == true,
                onToggle = { grantedMap["Call Log"] = !(grantedMap["Call Log"] ?: false) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}

@Composable
private fun PermissionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isGranted: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("permission_$title"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyanNeon.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(22.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            if (isGranted) {
                StatusPill(text = "Granted", color = SuccessGreen)
            } else {
                Button(
                    onClick = onToggle,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Ask", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
