package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Cyber Dark Palette
val BackgroundDark = Color(0xFF080C14)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceVariantDark = Color(0xFF1E293B)
val SurfaceCard = Color(0xFF131D31)
val SurfaceCardBorder = Color(0xFF1E3A5F)

// Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanNeonDim = Color(0xFF00B0FF)
val VioletNeon = Color(0xFF7C4DFF)
val VioletNeonDim = Color(0xFF9E00FF)
val MagentaNeon = Color(0xFFFF2A85)

// Functional Status
val SuccessGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF5252)
val InfoBlue = Color(0xFF29B6F6)

// Text & Neutral
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val DividerColor = Color(0xFF1E293B)
