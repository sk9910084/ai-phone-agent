package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AgentSkill
import com.example.ui.components.StatusPill
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon

@Composable
fun SelfLearningScreen(
    skills: List<AgentSkill>,
    onBack: () -> Unit,
    onStartLearningSkill: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var newSkillInput by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    val activeLearningSkill = skills.firstOrNull { it.status == "LEARNING" } ?: skills.firstOrNull()
    val completedSkills = skills.filter { it.status == "READY" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
            .testTag("self_learning_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Text(
                        text = "Self Learning",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                StatusPill(text = "Active", color = SuccessGreen)
            }
        }

        item {
            // Tabs: Learning, Skills, Sources
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = SurfaceCard,
                contentColor = CyanNeon,
                indicator = {},
                divider = {},
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(12.dp))
            ) {
                listOf("Learning", "Skills", "Sources").forEachIndexed { idx, title ->
                    val isSel = selectedTab == idx
                    Tab(
                        selected = isSel,
                        onClick = { selectedTab = idx },
                        modifier = Modifier
                            .background(if (isSel) CyanNeon.copy(alpha = 0.2f) else Color.Transparent)
                            .testTag("learn_tab_$title")
                    ) {
                        Text(
                            text = title,
                            color = if (isSel) CyanNeon else TextSecondary,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }

        if (selectedTab == 0 && activeLearningSkill != null) {
            item {
                // Active Learning Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Mai abhi naya skill seekh raha hu...",
                            fontSize = 14.sp,
                            color = TextPrimary,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Topic: ${activeLearningSkill.title}",
                                fontSize = 13.sp,
                                color = CyanNeon,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${activeLearningSkill.progress}%",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = VioletNeon
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { activeLearningSkill.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = VioletNeon,
                            trackColor = SurfaceVariantDark
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val steps = listOf(
                            "Documentation padh raha hu",
                            "Examples analyze kar raha hu",
                            "Practice run kar raha hu",
                            "Skill test kar raha hu",
                            "Ready to use"
                        )

                        val currentIdx = when {
                            activeLearningSkill.progress >= 95 -> 4
                            activeLearningSkill.progress >= 75 -> 3
                            activeLearningSkill.progress >= 50 -> 2
                            activeLearningSkill.progress >= 25 -> 1
                            else -> 0
                        }

                        steps.forEachIndexed { idx, st ->
                            val done = idx <= currentIdx
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (done) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                                } else {
                                    Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = TextSecondary.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                }
                                Text(
                                    text = st,
                                    fontSize = 13.sp,
                                    color = if (done) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            // New Skill Input Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Agent ko Naya Skill Sikhayein",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newSkillInput,
                        onValueChange = { newSkillInput = it },
                        modifier = Modifier.fillMaxWidth().testTag("new_skill_input"),
                        placeholder = { Text("Jaise: 'Expense audit report generator'", fontSize = 12.sp, color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (newSkillInput.isNotBlank()) {
                                onStartLearningSkill(newSkillInput)
                                newSkillInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                        modifier = Modifier.fillMaxWidth().testTag("start_learn_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Skill Seekhna Shuru Karein", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            // Recent Learnings Header
            Text(
                text = "Recent Learnings & Skills",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(completedSkills) { sk ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(VioletNeon.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = VioletNeon, modifier = Modifier.size(22.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(sk.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("${sk.dateLearned} · ${sk.category}", fontSize = 11.sp, color = TextSecondary)
                    }
                    StatusPill(text = "Ready", color = SuccessGreen)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
