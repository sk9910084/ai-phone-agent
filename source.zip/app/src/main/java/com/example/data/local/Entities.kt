package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "agent_tasks")
data class AgentTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val instruction: String,
    val status: String, // PENDING, PLANNING, RUNNING, WAITING_FOR_APPROVAL, COMPLETED, FAILED, CANCELLED
    val progress: Int = 0,
    val currentStep: String = "",
    val resultSummary: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val stepsJson: String = "", // Comma-separated or formatted steps
    val generatedFilesJson: String = "",
    val toolsUsed: String = "Local Engine",
    val category: String = "Productivity",
    val requiresApproval: Boolean = false,
    val approvalAction: String = ""
)

@Entity(tableName = "agent_skills")
data class AgentSkill(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String,
    val description: String,
    val progress: Int = 100,
    val status: String = "READY", // ACTIVE, LEARNING, READY
    val stepsListJson: String = "",
    val isCustom: Boolean = false,
    val dateLearned: String = "Today"
)

@Entity(tableName = "agent_integrations")
data class AgentIntegration(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // APP, AI_MODEL, API
    val isConnected: Boolean,
    val description: String,
    val iconCategory: String
)

@Entity(tableName = "agent_logs")
data class AgentLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: Long = 0,
    val level: String, // INFO, ACTION, WARNING, ERROR, SUCCESS
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)
