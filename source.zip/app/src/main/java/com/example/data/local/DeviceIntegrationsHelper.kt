package com.example.data.local

import android.content.Context
import android.content.pm.PackageManager

class DeviceIntegrationsHelper(private val context: Context, private val apiKeyManager: ApiKeyManager) {

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    fun getHonestIntegrations(): List<AgentIntegration> {
        val hasGemini = apiKeyManager.hasValidApiKey()
        val hasWhatsApp = isPackageInstalled("com.whatsapp")
        val hasGmail = isPackageInstalled("com.google.android.gm")
        val hasDrive = isPackageInstalled("com.google.android.apps.docs")
        val hasYouTube = isPackageInstalled("com.google.android.youtube")
        val hasTelegram = isPackageInstalled("org.telegram.messenger")
        val hasNotion = isPackageInstalled("notion.id")

        return listOf(
            AgentIntegration(
                name = "Local Phone Storage",
                type = "APP",
                isConnected = true,
                description = "Connected (100% On-Device SQLite & Sandboxed Storage)",
                iconCategory = "folder"
            ),
            AgentIntegration(
                name = "Gemini AI Engine",
                type = "AI_MODEL",
                isConnected = hasGemini,
                description = if (hasGemini) "Connected (Active in Settings)" else "Not Connected (API key required in Settings)",
                iconCategory = "ai"
            ),
            AgentIntegration(
                name = "WhatsApp",
                type = "APP",
                isConnected = hasWhatsApp,
                description = if (hasWhatsApp) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "chat"
            ),
            AgentIntegration(
                name = "Gmail",
                type = "APP",
                isConnected = hasGmail,
                description = if (hasGmail) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "email"
            ),
            AgentIntegration(
                name = "Google Drive",
                type = "APP",
                isConnected = hasDrive,
                description = if (hasDrive) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "folder"
            ),
            AgentIntegration(
                name = "YouTube",
                type = "APP",
                isConnected = hasYouTube,
                description = if (hasYouTube) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "video"
            ),
            AgentIntegration(
                name = "Telegram",
                type = "APP",
                isConnected = hasTelegram,
                description = if (hasTelegram) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "chat"
            ),
            AgentIntegration(
                name = "Notion",
                type = "APP",
                isConnected = hasNotion,
                description = if (hasNotion) "Connected (Installed on device)" else "Not Connected (App not installed)",
                iconCategory = "notes"
            ),
            AgentIntegration(
                name = "OpenAI",
                type = "AI_MODEL",
                isConnected = false,
                description = "Not Connected (External service not configured)",
                iconCategory = "ai"
            ),
            AgentIntegration(
                name = "Claude",
                type = "AI_MODEL",
                isConnected = false,
                description = "Not Connected (External service not configured)",
                iconCategory = "ai"
            )
        )
    }
}
