package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM agent_tasks ORDER BY timestamp DESC")
    fun getAllTasks(): Flow<List<AgentTask>>

    @Query("SELECT * FROM agent_tasks WHERE id = :taskId LIMIT 1")
    suspend fun getTaskById(taskId: Long): AgentTask?

    @Query("SELECT * FROM agent_tasks WHERE id = :taskId LIMIT 1")
    fun observeTaskById(taskId: Long): Flow<AgentTask?>

    @Query("SELECT COUNT(*) FROM agent_tasks WHERE status = 'COMPLETED'")
    fun getCompletedTaskCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM agent_tasks WHERE status = 'COMPLETED'")
    suspend fun getCompletedTaskCountDirect(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: AgentTask): Long

    @Update
    suspend fun updateTask(task: AgentTask)

    @Query("DELETE FROM agent_tasks WHERE id = :taskId")
    suspend fun deleteTask(taskId: Long)

    @Query("DELETE FROM agent_tasks")
    suspend fun clearAllTasks()
}

@Dao
interface SkillDao {
    @Query("SELECT * FROM agent_skills ORDER BY id DESC")
    fun getAllSkills(): Flow<List<AgentSkill>>

    @Query("SELECT COUNT(*) FROM agent_skills")
    fun observeSkillCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkill(skill: AgentSkill): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSkills(skills: List<AgentSkill>)

    @Update
    suspend fun updateSkill(skill: AgentSkill)

    @Query("SELECT COUNT(*) FROM agent_skills")
    suspend fun getSkillCount(): Int
}

@Dao
interface IntegrationDao {
    @Query("SELECT * FROM agent_integrations ORDER BY id ASC")
    fun getAllIntegrations(): Flow<List<AgentIntegration>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntegrations(list: List<AgentIntegration>)

    @Update
    suspend fun updateIntegration(integration: AgentIntegration)

    @Query("SELECT COUNT(*) FROM agent_integrations")
    suspend fun getCount(): Int
}

@Dao
interface LogDao {
    @Query("SELECT * FROM agent_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentLogs(): Flow<List<AgentLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AgentLog)

    @Query("DELETE FROM agent_logs")
    suspend fun clearLogs()
}

@Database(
    entities = [AgentTask::class, AgentSkill::class, AgentIntegration::class, AgentLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun skillDao(): SkillDao
    abstract fun integrationDao(): IntegrationDao
    abstract fun logDao(): LogDao
}
