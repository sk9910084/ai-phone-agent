package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ApiKeyManager
import com.example.data.local.DeviceIntegrationsHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Phone Agent", appName)
    }

    @Test
    fun `apiKeyManager stores and retrieves key correctly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val keyManager = ApiKeyManager(context)
        keyManager.setApiKey("test-gemini-key-12345")
        assertEquals("test-gemini-key-12345", keyManager.getApiKey())
        assertTrue(keyManager.hasValidApiKey())

        keyManager.setApiKey("")
        assertEquals("", keyManager.getApiKey())
        assertFalse(keyManager.hasValidApiKey())
    }

    @Test
    fun `honest integrations verify local storage and uninstalled packages`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val keyManager = ApiKeyManager(context)
        keyManager.setApiKey("")
        val helper = DeviceIntegrationsHelper(context, keyManager)
        val integrations = helper.getHonestIntegrations()

        // Local storage is verified and connected
        val localStorage = integrations.firstOrNull { it.name == "Local Phone Storage" }
        assertTrue(localStorage != null && localStorage.isConnected)

        // Gemini AI Engine requires API key in settings
        val gemini = integrations.firstOrNull { it.name == "Gemini AI Engine" }
        assertTrue(gemini != null && !gemini.isConnected)

        // Uninstalled apps like OpenAI are not connected
        val openAi = integrations.firstOrNull { it.name == "OpenAI" }
        assertTrue(openAi != null && !openAi.isConnected)
    }
}
